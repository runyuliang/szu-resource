#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define ALLOC_SIZE (256 * 1024 * 1024)  // 256MB
#define PAGE_SIZE (4 * 1024)            // 4KB

void print_memory_info(pid_t pid, const char *tag) {
  char path[256];
  snprintf(path, sizeof(path), "/proc/%d/status", pid);
  printf("==== %s: %s ====\n", tag, path);
  FILE *fp = fopen(path, "r");
  if (fp) {
    char line[256];
    while (fgets(line, sizeof(line), fp)) {
      if (strstr(line, "VmSize") || strstr(line, "VmRSS") ||
          strstr(line, "VmData")) {
        printf("%s", line);
      }
    }
    fclose(fp);
  } else {
    perror("fopen");
  }
}

void touch_memory(char *mem, int write) {
  for (size_t i = 0; i < ALLOC_SIZE; i += PAGE_SIZE) {
    if (write) {
      mem[i] = 'A';  // 写操作
    } else {
      char c = mem[i];  // 读操作
      (void)c;
    }
  }
}

int main() {
  pid_t pid = getpid();

  // 初始内存信息
  print_memory_info(pid, "Initial");

  // 分配256MB内存
  char *mem = (char *)malloc(ALLOC_SIZE);
  if (mem == NULL) {
    fprintf(stderr, "Memory allocation failed\n");
    return 1;
  }

  // 分配后内存信息
  print_memory_info(pid, "After malloc");

  // 读操作
  touch_memory(mem, 0);
  print_memory_info(pid, "After read operations");

  // 写操作
  touch_memory(mem, 1);
  print_memory_info(pid, "After write operations");

  // 释放内存
  free(mem);
  print_memory_info(pid, "After free");

  return 0;
}