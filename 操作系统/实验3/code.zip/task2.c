#include <stdio.h>
#include <stdlib.h>

#define ALLOC_SIZE (1024 * 1024 * 1024)  // 每次分配1GB

int main() {
  size_t allocated = 0;
  void *ptr = NULL;

  while (1) {
    ptr = malloc(ALLOC_SIZE);
    if (ptr == NULL) {
      printf("Memory allocation failed at %zu bytes (%.2f GB)\n", allocated,
             (double)allocated / (1024 * 1024 * 1024));
      break;
    }
    allocated += ALLOC_SIZE;
    printf("Allocated %zu bytes (%.2f GB)\n", allocated,
           (double)allocated / (1024 * 1024 * 1024));
  }

  return 0;
}