#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

void print_memory_info(pid_t pid, const char* tag) {
  char path[256];
  FILE* fp;

  // Print maps file
  snprintf(path, sizeof(path), "/proc/%d/maps", pid);
  printf("==== %s: %s ====\n", tag, path);
  fp = fopen(path, "r");
  if (fp) {
    char line[256];
    while (fgets(line, sizeof(line), fp)) {
      printf("%s", line);
    }
    fclose(fp);
  } else {
    perror("fopen");
  }

  // Print status file
  snprintf(path, sizeof(path), "/proc/%d/status", pid);
  printf("==== %s: %s ====\n", tag, path);
  fp = fopen(path, "r");
  if (fp) {
    char line[256];
    while (fgets(line, sizeof(line), fp)) {
      if (strstr(line, "VmSize") || strstr(line, "VmRSS") ||
          strstr(line, "VmData")) {
        printf("%s", line);
      }
    }
    fclose(fp);
  } else {
    perror("fopen");
  }
}

int main() {
  pid_t pid = getpid();

  // 初始内存信息
  print_memory_info(pid, "Initial");

  // 申请六个128MB的空间
  void* ptr1 = malloc(128 * 1024 * 1024);
  void* ptr2 = malloc(128 * 1024 * 1024);
  void* ptr3 = malloc(128 * 1024 * 1024);
  void* ptr4 = malloc(128 * 1024 * 1024);
  void* ptr5 = malloc(128 * 1024 * 1024);
  void* ptr6 = malloc(128 * 1024 * 1024);

  // 检查内存分配是否成功
  if (ptr1 == NULL || ptr2 == NULL || ptr3 == NULL || ptr4 == NULL ||
      ptr5 == NULL || ptr6 == NULL) {
    fprintf(stderr, "Memory allocation failed\n");
    return 1;
  }
  print_memory_info(pid, "After allocating six 128MB blocks");

  // 释放第2、3、5号的128MB空间
  free(ptr2);
  free(ptr3);
  free(ptr5);
  print_memory_info(pid, "After freeing the 2nd, 3rd, and 5th 128MB blocks");

  // 再分配1024MB的空间
  void* ptr7 = malloc(1024 * 1024 * 1024);
  if (ptr7 == NULL) {
    fprintf(stderr, "Memory allocation failed\n");
    return 1;
  }
  print_memory_info(pid, "After allocating 1024MB block");

  // 再分配64MB的空间
  void* ptr8 = malloc(64 * 1024 * 1024);
  if (ptr7 == NULL) {
    fprintf(stderr, "Memory allocation failed\n");
    return 1;
  }

  printf("%p - %p\n", ptr8, ptr8 + 64 * 1024 * 1024);
  print_memory_info(pid, "After allocating 64MB block");

  // 释放所有剩余的内存
  free(ptr1);
  free(ptr4);
  free(ptr6);
  free(ptr7);
  free(ptr8);
  return 0;
}